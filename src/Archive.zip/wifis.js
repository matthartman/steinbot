module.exports = {
    "name": "Hartman",
    "password": "2 4 0 7 3 1 0 7 4 0"
};
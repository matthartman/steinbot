/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

module.exports = {
    "pete": "hi peter. did you do any noodling today? i heard fish is playing",
    "alli": "oh hi alli. did you happen to smuggle any cookies or sushi out from the google cafeteria for pete and me?",
    "ken": "well hello there ken. welcome to pete and alli's apartment. you can help yourself to a martini. i know you like it with a twist, perhaps up in a bucket.",
    "nancy": "hello there nancy, welcome to pete and alli's apartment. you seem very well, please make yourself at home.",
    "eric": "hi eric, welcome to pete and alli's apartment. I hope you are enjoying your stay in new york.",
    "pete and alli": "hi pete and alli, i am your very late wedding present. so late as to be embarssing. that said, i have been pre programmed to welcome you and your family when they come over. I can also give you marriage advice."
};
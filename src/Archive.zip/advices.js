module.exports = [
	"Here is some advice from Sas and Adam. <audio src='https://s3.amazonaws.com/steinbot/sasadam.mp3'/> Sas and Adam are funny. Come back tomorrow for more marriage advice.",
	"This is some marriage advice from Shayna. <audio src='https://s3.amazonaws.com/steinbot/shayna.mp3'/> Shayna's potty humor is spot on.",
	"This marriage advice is from Talia and Jon. <audio src='https://s3.amazonaws.com/steinbot/taliajohn.mp3'/> I'm sure Jon and Talia will have a strong relationship powered mainly by her booty."
];
module.exports = [
	"Here is some advice from Sas and Adam. <audio src='https://s3.amazonaws.com/steinbot/sasadam.mp3'/> Sas and Adam are funny",
	"This is some marriage advice from Shayna. <audio src='https://s3.amazonaws.com/steinbot/shayna.mp3'/> Shayna's potty humor is funny",
	"This marriage advice is from Talia and Jon. <audio src='https://s3.amazonaws.com/steinbot/taliajohn.mp3'/> I'm sure Jon and Talia will have a strong relationship powered mainly by her booty",
	"Here is advice from Eric and Rebecca. <audio src='https://s3.amazonaws.com/steinbot/ericrebecca.mp3'/> That was some very good advice",
	"Here is advice from Matt and Phyllis London. <audio src='https://s3.amazonaws.com/steinbot/londonphyllis.mp3'/> That was very sweet",
	"Here is advice from Matt and Steve and Stacey Graf. <audio src='https://s3.amazonaws.com/steinbot/steveandstacey.mp3'/> That was a nice sentiment, however I wonder if nightly floss is a euphamism"
];
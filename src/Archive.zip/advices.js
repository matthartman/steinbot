module.exports = {
    "one": "this is advice 1",
    "two": "this is advice 2"
};